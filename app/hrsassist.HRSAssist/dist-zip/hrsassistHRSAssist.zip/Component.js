sap.ui.define(["sap/fe/core/AppComponent"],function(s){"use strict";return s.extend("hrsassist.HRSAssist.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map